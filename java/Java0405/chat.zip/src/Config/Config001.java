package Config;

import java.util.Date;
import java.text.SimpleDateFormat;

public interface Config001 {
	public static final String ServerIP = "10.100.104.4";
	public static final int    Port 	= 7777;
	
	public static String getTime() {
		SimpleDateFormat f = new SimpleDateFormat("[hh:mm:ss]");
		return f.format(new Date());
	}
}
